//This package defines Lead Management json data model
package ev_lm_json


type Homeowner struct {
    HomeownerId     string      `json:"homeownerId"`
    Username        string      `json:"username"`
    FirstName	    string      `json:"firstName"`
    LastName	    string      `json:"lastName"`
    Phone	        string      `json:"phone"`
    Email	        string      `json:"email"`
    UserStatus	    string 	    `json:"userStatus"`
    CustomNotes     string      `json:"customNotes"`
    HouseholdType   string      `json:"householdType"`
}

/*type SecondaryUser struct {
    HomeownerId     string      `json:"homeownerId"`
    Username        string      `json:"username"`
    FirstName	    string      `json:"firstName"`
    LastName	    string      `json:"lastName"`
    Phone	        string      `json:"phone"`
    Email	        string      `json:"email"`
    UserStatus	    string 	    `json:"userStatus"`
    CustomNotes     string      `json:"customNotes"`
    HouseholdType   string      `json:"householdType"`
}*/

type AssignedTo struct{
    UserId          string      `json:"userId"`
    CompanyId       string      `json:"companyId"`
}

type Address struct{
    AddressId       string      `json:"addressId"`
    AddressLine1    string      `json:"addressLine1"`
    AddressLine2    string      `json:"addressLine2"`
    City            string      `json:"city"` 
    State           string      `json:"state"`
    Zip             string      `json:"zip"`
}

type Lead struct {
    Id              string      `json:"id"`
    PrimaryUser     string      `json:"primaryUser"`
    SecondaryUser   string      `json:"secondaryUser"`
    JobType         string      `json:"jobType"`
    LeadStatus      string      `json:"leadStatus"`
    LeadSource      string      `json:"leadSource"`
    AssignedTo      string      `json:"assignedTo"`
    Address         string      `json:"address"`
    Status          string      `json:"status"`
    CompanyId       string      `json:"companyId"`
}

/*type Lead struct {
    Id              string      `json:"id" gorm:"Column:ID"`
    PrimaryUser     string      `json:"primaryUser" gorm:"column:PrimaryUser"`
    SecondaryUser   string      `json:"secondaryUser" gorm:"column:SecondaryUser"`
    JobType         string      `json:"jobType" gorm:"column:JobType"`
    LeadStatus      string      `json:"leadStatus" gorm:"column:LeadStatus"`
    LeadSource      string      `json:"leadSource" gorm:"column:LeadSource"`
    AssignedTo      string      `json:"assignedTo" gorm:"column:AssignedTo"`
    Address         string      `json:"address" gorm:"column:Address"`
    Status          string      `json:"status" gorm:"column:Status"`
    CompanyId       string      `json:"companyId" gorm:"column:CompanyId"`
}*/

type ApiResponse struct {
	Code            int 		 `json:"code"`
    Type            string 		 `json:"type"`
    Message         string 		 `json:"message"`
}

type LeadDetails struct{
    Id                     string           `json:"id"`
    PrimaryUserDetails     Homeowner        `json:"primaryUser"`
    SecondaryUserDetails   Homeowner        `json:"secondaryUser"`
    JobType                string           `json:"jobType"`
    LeadStatus             string           `json:"leadStatus"`
    LeadSource             string           `json:"leadSource"`
    AssignedToDetails      AssignedTo       `json:"assignedTo"`
    AddressesDetails       Address          `json:"address"`
    Status                 string           `json:"status"`
    CompanyId              string           `json:"companyId"`
}