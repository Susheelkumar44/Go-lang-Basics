package ev_lm_updateLead

import (
	"github.com/labstack/echo"
	"net/http"
	"encoding/json"
	"LeadMgmt/ev_lm_json"
	"log"
	//"fmt"
	//"reflect"
	query "lib/database/query"
)

func UpdateLead(c echo.Context) error {

	response := ev_lm_json.ApiResponse{}
	leadDetails := ev_lm_json.LeadDetails{}
	lead := ev_lm_json.Lead{}


	defer c.Request().Body.Close()
	errLead := json.NewDecoder(c.Request().Body).Decode(&leadDetails)
	
	if errLead != nil{
			response.Code=500
			response.Type = errLead.Error()
			response.Message="Error in decoding JSON object"
			log.Println(errLead)
			return errLead
		
	}else{

		lead.Id =leadDetails.Id
		//fmt.Println(lead.Id)
		//fmt.Println(reflect.TypeOf(lead.Id))
		lead.PrimaryUser = leadDetails.PrimaryUserDetails.HomeownerId
		lead.SecondaryUser = leadDetails.SecondaryUserDetails.HomeownerId
		lead.JobType = leadDetails.JobType
		lead.LeadStatus = leadDetails.LeadStatus
		lead.LeadSource = leadDetails.LeadSource
		lead.AssignedTo = leadDetails.AssignedToDetails.UserId
		lead.Address = leadDetails.AddressesDetails.AddressId
		lead.Status = leadDetails.Status
		//log.Println("lead: %s",lead)

	
		response = query.UpdateLead(lead)
		c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
		c.Response().WriteHeader(http.StatusOK)
		return json.NewEncoder(c.Response()).Encode(response)
	}
}