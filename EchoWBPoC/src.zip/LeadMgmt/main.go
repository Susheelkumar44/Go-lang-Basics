/**
* 
*
* @author  Capgemini
* @version v1
* @since   2019-22-05
*/
package main

import (
	"github.com/labstack/echo"
	db "lib/database/dbLayer"
	config "lib/configuration"
	ev_lm_updateLead "LeadMgmt/ev_lm_updateLead"
)

func main() {
	config, _ := config.ExtractConfiguration(/**confPath*/)
	connection := db.ConnectToDatabase(config)
	defer connection.Close()
	e := echo.New()
	e.PUT("/updateLead",ev_lm_updateLead.UpdateLead)
	e.Start(":8099")
	
}