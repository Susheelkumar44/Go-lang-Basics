package dbLayer

import (
    "github.com/jinzhu/gorm"
    "lib/configuration"
    "lib/database/query"
    "fmt"
    "log"
    _ "github.com/lib/pq"
)
 
func ConnectToDatabase(config configuration.ServiceConfig ) *gorm.DB {
    //host :=""
    dbinfo := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=disable",
    config.HOST, config.DB_USER, config.DB_PASSWORD, config.DB_NAME, config.PORT) 
    db, err := gorm.Open("postgres", dbinfo)
    if err != nil {
        fmt.Println(err)
    }
    log.Printf("Postgres started at %s PORT", config.PORT)
    query.SetDatabase(db)		
    return db
}


