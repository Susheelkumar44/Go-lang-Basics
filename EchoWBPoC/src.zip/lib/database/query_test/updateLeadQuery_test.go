package query_test

import(
	"github.com/stretchr/testify/assert"
	"testing"
	model "LeadMgmt/ev_lm_json"
	"lib/database/query"
    config "lib/configuration"
    db "lib/database/dbLayer"
	
)

func TestUpdateLeadSucess(t *testing.T){
	config, _ := config.ExtractConfiguration(/**confPath*/)
	connection := db.ConnectToDatabase(config)
	defer connection.Close()

	expected := model.ApiResponse{
		Code : 200,
		Type : "OK",
		Message : "Success",
	}

	lead := model.Lead{
		Id : "0",
		PrimaryUser : "0",
		SecondaryUser : "2",
    	JobType : "string",
		LeadStatus : "string", 	
		LeadSource : "string",
		AssignedTo : "0",
    	Address : "0",
    	Status : "converted",
	}
	result := query.UpdateLead(lead)

	assert.Equal(t,expected,result)
}

