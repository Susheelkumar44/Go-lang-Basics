package query

import(
	model "LeadMgmt/ev_lm_json"
//	"log"
	//"strconv"
	//"reflect"
	//"fmt"
)


func UpdateLead(lead model.Lead) model.ApiResponse{

	response:= model.ApiResponse{}
	/*var exists bool
	//fmt.Println(lead.PrimaryUser)
	primaryUserId, err:= strconv.Atoi(lead.PrimaryUser)
	//fmt.Println(primaryUserId)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid ID Supplied"
		return response
	}
	secondaryUserId, err := strconv.Atoi(lead.SecondaryUser)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid ID Supplied"
		return response
	}
	assignedToId, err := strconv.Atoi(lead.AssignedTo)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid ID Supplied"
		return response
	} 
	addressId, err := strconv.Atoi(lead.Address)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid ID Supplied"
		return response
	} 
	leadId, err:= strconv.Atoi(lead.Id)
	fmt.Println(leadId)
	if err!=nil{
				response.Code=400
				response.Type=err.Error()
				response.Message="Invalid ID Supplied"
		return response
	}*/
		/*row := db.QueryRow(`SELECT EXISTS (SELECT * FROM public."LEADS" WHERE "ID"=$1)`,leadId)
		errRowScan := row.Scan(&exists)
		if errRowScan == nil && !exists{
			response.Code = 404
			response.Type = "ID Cannot be located in our Database"
			response.Message = "LeadMgmt Not Found"
			return response
			}*/

		/*_, dBerr := db.Exec(`UPDATE public."LEADS" SET "PRIMARYUSER"=$1, "SECONDARYUSER"=$2, "JOBTYPE"=$3, 
							"LEADSTATUS"=$4, "LEADSOURCE"=$5, "ASSIGNEDTO"=$6, "ADDRESS"=$7, "STATUS"=$8 
							WHERE "ID"=$9`,primaryUserId, secondaryUserId, lead.JobType,lead.LeadStatus,
							lead.LeadSource, assignedToId, addressId, lead.Status, leadId)

		*/
		db.Model(&lead).Where("ID =?",lead.Id).Update(model.Lead{PrimaryUser:lead.PrimaryUser, SecondaryUser:lead.SecondaryUser,
							  JobType:lead.JobType, LeadStatus:lead.LeadStatus, LeadSource: lead.LeadSource,
							  AssignedTo:lead.AssignedTo, Address: lead.Address, Status:lead.Status})
		
		
				response.Code=200
				response.Type="OK"
				response.Message="Success"
			return response
		
	
}

/*func IntConverter(id string) (int,model.ApiResponse){

	response:= model.ApiResponse{}

	intId, err:= strconv.Atoi(id)
	if err!=nil{
		response.Code=400
		response.Type = err.Error()
		response.Message="Invalid ID Supplied"
	}
	return intId,response
}*/
